package com.raq.springboot.employee.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.raq.springboot.employee.vo.EmployeeVO;
import com.raq.springboot.employee.vo.EmployeeVORepository;

@Service
public class EmployeeService {

	private List<EmployeeVO> employees = new ArrayList<>(Arrays.asList(new EmployeeVO(1, "AbdulRaquib", 20, 2000d),
			new EmployeeVO(2, "SyedJaffarAli", 30, 3000d), new EmployeeVO(3, "AbdulRaafay", 40, 4000d)));

	@Autowired
	private EmployeeVORepository employeeVORepository;

	public List<EmployeeVO> getEmployees() {
		Iterable<EmployeeVO> itr = employeeVORepository.findAll();
		List<EmployeeVO> lst = new ArrayList<EmployeeVO>();
		Iterator<EmployeeVO> iterator = itr.iterator();
		while (iterator.hasNext()) {
			EmployeeVO employeeVO = (EmployeeVO) iterator.next();
			lst.add(employeeVO);
		}
		System.out.println("EmployeeService.getEmployees() invoked " + lst);
		return lst;
	}

	public EmployeeVO getEmployee(int id) {
		System.out.println("EmployeeService.getEmployee(id) invoked " + id);
		Optional<EmployeeVO> employeeId = employeeVORepository.findById(id);
		return employeeId.get();
//		return employees.stream().filter(t -> t.getId() == id).findFirst().get();
	}

	public void addEmployee(EmployeeVO employee) {
		employeeVORepository.save(employee);
//		employees.add(employee);
		System.out.println("EmployeeService.addEmployee() invoked " + employee);
	}

	public void updateEmployee(EmployeeVO employee) {
		employeeVORepository.save(employee);
		System.out.println("EmployeeService.updateEmployee() invoked " + employee);

	}

	public void deleteEmployee(int id) {
		System.out.println("EmployeeService.deleteEmployee() invoked " + id);
		employeeVORepository.deleteById(id);
	}

}
