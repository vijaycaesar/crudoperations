package com.raq.springboot.employee.vo;

import org.springframework.data.repository.CrudRepository;

public interface EmployeeVORepository extends CrudRepository<EmployeeVO, Integer> {

}
